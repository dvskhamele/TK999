# TK999 Deployment Package

This package contains both the frontend and backend for the TK999 betting platform, ready for deployment to Vercel.

## Project Structure

- `/frontend` - React frontend application
- `/backend` - Node.js/Express backend API
- `vercel.json` - Root configuration for Vercel deployment

## Deployment Instructions

### Option 1: Deploy to Vercel (Recommended)

1. Create an account at [vercel.com](https://vercel.com)
2. Install the Vercel CLI: `npm install -g vercel`
3. Navigate to this directory
4. Run `vercel` to deploy

The project is configured with:
- Frontend routes handled by Vite static files
- Backend API routes prefixed with `/api/`
- Automatic build and deployment

### Option 2: Manual Deployment

1. Build the project:
   ```
   npm run build
   ```

2. The frontend will be built to `frontend/dist/`
3. Deploy the frontend and backend separately to your hosting provider

## Local Development

To run both frontend and backend locally:
```
npm run dev
```

To run frontend only:
```
cd frontend && npm run dev
```

To run backend only:
```
cd backend && npm run dev
```

## Environment Variables

Make sure to set the following environment variables in your Vercel project settings:

- `VITE_API_URL` - The URL of your backend API (for frontend)
- Any other environment variables required by your backend

## Notes

- The frontend is built with React, TypeScript, and Vite
- The backend is built with Node.js and Express
- Both projects are configured to work with Vercel's deployment platform
- Frontend runs on port 5173 locally
- Backend runs on port 5001 locally