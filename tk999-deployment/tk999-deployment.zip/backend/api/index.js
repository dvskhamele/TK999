const handler = require('./handler.js');

module.exports = handler;