#!/bin/bash

# Startup script for TK999 application

echo "Starting TK999 application..."

# Start frontend
echo "Starting frontend server..."
cd frontend
npm run dev &
FRONTEND_PID=$!
cd ..

# Start backend
echo "Starting backend server..."
cd backend
npm run dev &
BACKEND_PID=$!
cd ..

# Function to kill child processes on exit
cleanup() {
  echo "Stopping servers..."
  kill $FRONTEND_PID $BACKEND_PID
  exit 0
}

# Trap SIGINT and SIGTERM
trap cleanup SIGINT SIGTERM

echo "Frontend running on http://localhost:5173"
echo "Backend running on http://localhost:5001"

# Wait for both processes
wait $FRONTEND_PID $BACKEND_PID